//lab1,task8



import java.util.Scanner;

public class speed_in_miles{



public static void main(String args[]){

Scanner src=new Scanner(System.in);



System.out.print("Enter a speed in miles per hour: ");

int speed=src.nextInt();

System.out.println("The converted value is: "+(speed*1.6));



}

}