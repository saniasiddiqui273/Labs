//lab1,task5

import java.util.Scanner;
public class pattern{

public static void main(String args[]){
Scanner src=new Scanner(System.in);
System.out.print("*********\n*\t*\n*\t*\n*\t*\n*********");

}}