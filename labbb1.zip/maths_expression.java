//lab3,task4

import java.util.Scanner;
public class maths_expression{
public static void main(String args[]){
Scanner src=new Scanner(System.in);
System.out.println((10+5)*(4-6)/4);

}
}