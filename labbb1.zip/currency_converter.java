//lab1,task6
import java.util.Scanner;
public class currency_converter{

public static void main(String args[]){
Scanner src=new Scanner(System.in);
System.out.println("Enter the Dollors: ");
double dollors= src.nextDouble();
System.out.println("Values in rupees: "+dollors*278.82);


}
}