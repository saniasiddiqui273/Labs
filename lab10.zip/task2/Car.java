public class Car implements Vehicle{
public void start(){
System.out.println("Car engine started");
}

public void stop(){
System.out.println("Car engine stopped.");
}

}