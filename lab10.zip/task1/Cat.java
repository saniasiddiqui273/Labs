public class Cat extends Animal{
public void makeSound(){

   System.out.println("Cat Meows.");
}

}