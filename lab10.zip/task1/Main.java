class Main {
   public static void main(String [] args){

Dog dog = new Dog();
Cat cat = new Cat();

	dog.eat();
dog.makeSound();

cat.eat();
cat.makeSound();
}
}