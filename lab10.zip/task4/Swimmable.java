public interface Swimmable {
   void swim();
}